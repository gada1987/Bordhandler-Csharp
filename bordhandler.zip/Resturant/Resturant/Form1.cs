﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Resturant
{
    public partial class Form1 : Form
    {

        string[] BordLista = new string[9];

        int bord = 0;
        int bordPersoner;
        string bordnamn = null;
        int val = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Boka_Click(object sender, EventArgs e)
        {
            BokaÄndra.Hide();
            MainMeny.Hide();
            BordÄndra.Show();
            ÄndraMeny.Hide();
        }

        private void Ändra_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            ÄndraMeny.Hide();
            BordÄndra.Show();
            val = 0;
        }

        private void ÄndraMethod(int Ä, string namn, int personer)
        {
            BordLista = File.ReadAllLines("Bord.hello");
            BordLista[Ä] = $"{namn},{personer}";
        }

        private void BordÄndra1_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 1;
        }

        private void BordÄndra2_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 2;
        }

        private void BordÄndra3_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 3;
        }

        private void BordÄndra4_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 4;
        }

        private void BordÄndra5_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 5;
        }

        private void BordÄndra6_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 6;
        }

        private void BordÄndra7_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 7;
        }

        private void BordÄndra8_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 8;
        }

        private void BordÄndra9_Click(object sender, EventArgs e)
        {
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Show();
            bord = 9;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bordnamn = textBox1.Text;
            bordPersoner = int.Parse(textBox2.Text);
            ÄndraMethod(bord, bordnamn, bordPersoner);
            File.WriteAllLines("Bord.hello", BordLista);
        }

        private void BokaÄndra_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            BordLista = File.ReadAllLines("Bord.hello");
            BordBoka.Hide();
            MainMeny.Hide();
            BordBoka.Hide();
            BordÄndra.Hide();
            ÄndraMeny.Hide();
            BokaÄndra.Hide();
            panel1.Show();
            BordLista = File.ReadAllLines("Bord.hello");
            label2.Text = BordLista[val].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BokaÄndra.Hide();
            MainMeny.Hide();
            BordÄndra.Show();
            ÄndraMeny.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (val < 9)
            {
                val++;
                Selected.Text = val.ToString();
                BordLista = File.ReadAllLines("Bord.hello");
                label2.Text = BordLista[val].ToString();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (val > 1)
            {
                val--;
                Selected.Text = val.ToString();
                BordLista = File.ReadAllLines("Bord.hello");
                label2.Text = BordLista[val].ToString();
            }
        }

        private void Välj_Click(object sender, EventArgs e)
        {
            BordLista[val] = "";
            File.WriteAllLines("Bord.hello", BordLista);
            label2.Text = BordLista[val].ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainMeny.Show();
            ÄndraMeny.Hide();
            BokaÄndra.Hide();
            BordÄndra.Hide();
            BordBoka.Hide();
            panel1.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
