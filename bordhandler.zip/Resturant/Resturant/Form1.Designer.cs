﻿namespace Resturant
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.MainMeny = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.BordBoka = new System.Windows.Forms.Panel();
            this.Bord8 = new System.Windows.Forms.Button();
            this.Bord9 = new System.Windows.Forms.Button();
            this.Bord5 = new System.Windows.Forms.Button();
            this.Bord3 = new System.Windows.Forms.Button();
            this.Bord7 = new System.Windows.Forms.Button();
            this.Bord6 = new System.Windows.Forms.Button();
            this.Bord2 = new System.Windows.Forms.Button();
            this.Bord4 = new System.Windows.Forms.Button();
            this.Bord1 = new System.Windows.Forms.Button();
            this.BokaÄndra = new System.Windows.Forms.Panel();
            this.Ändra = new System.Windows.Forms.Button();
            this.Boka = new System.Windows.Forms.Button();
            this.BordÄndra = new System.Windows.Forms.Panel();
            this.BordÄndra9 = new System.Windows.Forms.Button();
            this.BordÄndra8 = new System.Windows.Forms.Button();
            this.BordÄndra7 = new System.Windows.Forms.Button();
            this.BordÄndra6 = new System.Windows.Forms.Button();
            this.BordÄndra5 = new System.Windows.Forms.Button();
            this.BordÄndra4 = new System.Windows.Forms.Button();
            this.BordÄndra3 = new System.Windows.Forms.Button();
            this.BordÄndra2 = new System.Windows.Forms.Button();
            this.BordÄndra1 = new System.Windows.Forms.Button();
            this.ÄndraMeny = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Välj = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.Selected = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.MainMeny.SuspendLayout();
            this.BordBoka.SuspendLayout();
            this.BokaÄndra.SuspendLayout();
            this.BordÄndra.SuspendLayout();
            this.ÄndraMeny.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.label1.Location = new System.Drawing.Point(133, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(535, 126);
            this.label1.TabIndex = 0;
            this.label1.Text = "       Välkomen till \r\nCentralrestaurangen!";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.button1.Location = new System.Drawing.Point(308, 157);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 61);
            this.button1.TabIndex = 1;
            this.button1.Text = "Boka/Ändra";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainMeny
            // 
            this.MainMeny.AutoSize = true;
            this.MainMeny.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MainMeny.Controls.Add(this.button7);
            this.MainMeny.Controls.Add(this.button3);
            this.MainMeny.Controls.Add(this.button1);
            this.MainMeny.Controls.Add(this.label1);
            this.MainMeny.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainMeny.Location = new System.Drawing.Point(0, 0);
            this.MainMeny.Name = "MainMeny";
            this.MainMeny.Size = new System.Drawing.Size(800, 450);
            this.MainMeny.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.button3.Location = new System.Drawing.Point(308, 245);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 64);
            this.button3.TabIndex = 2;
            this.button3.Text = "Visa bokade bord/Töm bord";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // BordBoka
            // 
            this.BordBoka.Controls.Add(this.Bord8);
            this.BordBoka.Controls.Add(this.Bord9);
            this.BordBoka.Controls.Add(this.Bord5);
            this.BordBoka.Controls.Add(this.Bord3);
            this.BordBoka.Controls.Add(this.Bord7);
            this.BordBoka.Controls.Add(this.Bord6);
            this.BordBoka.Controls.Add(this.Bord2);
            this.BordBoka.Controls.Add(this.Bord4);
            this.BordBoka.Controls.Add(this.Bord1);
            this.BordBoka.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BordBoka.Location = new System.Drawing.Point(0, 0);
            this.BordBoka.Name = "BordBoka";
            this.BordBoka.Size = new System.Drawing.Size(800, 450);
            this.BordBoka.TabIndex = 2;
            this.BordBoka.Visible = false;
            // 
            // Bord8
            // 
            this.Bord8.Location = new System.Drawing.Point(300, 293);
            this.Bord8.Name = "Bord8";
            this.Bord8.Size = new System.Drawing.Size(153, 103);
            this.Bord8.TabIndex = 8;
            this.Bord8.Text = "Bord8";
            this.Bord8.UseVisualStyleBackColor = true;
            // 
            // Bord9
            // 
            this.Bord9.Location = new System.Drawing.Point(500, 293);
            this.Bord9.Name = "Bord9";
            this.Bord9.Size = new System.Drawing.Size(153, 103);
            this.Bord9.TabIndex = 9;
            this.Bord9.Text = "Bord9";
            this.Bord9.UseVisualStyleBackColor = true;
            // 
            // Bord5
            // 
            this.Bord5.Location = new System.Drawing.Point(300, 157);
            this.Bord5.Name = "Bord5";
            this.Bord5.Size = new System.Drawing.Size(153, 103);
            this.Bord5.TabIndex = 7;
            this.Bord5.Text = "Bord5";
            this.Bord5.UseVisualStyleBackColor = true;
            // 
            // Bord3
            // 
            this.Bord3.Location = new System.Drawing.Point(500, 32);
            this.Bord3.Name = "Bord3";
            this.Bord3.Size = new System.Drawing.Size(153, 103);
            this.Bord3.TabIndex = 6;
            this.Bord3.Text = "Bord3";
            this.Bord3.UseVisualStyleBackColor = true;
            // 
            // Bord7
            // 
            this.Bord7.Location = new System.Drawing.Point(100, 293);
            this.Bord7.Name = "Bord7";
            this.Bord7.Size = new System.Drawing.Size(153, 103);
            this.Bord7.TabIndex = 4;
            this.Bord7.Text = "Bord7";
            this.Bord7.UseVisualStyleBackColor = true;
            // 
            // Bord6
            // 
            this.Bord6.Location = new System.Drawing.Point(500, 157);
            this.Bord6.Name = "Bord6";
            this.Bord6.Size = new System.Drawing.Size(153, 103);
            this.Bord6.TabIndex = 3;
            this.Bord6.Text = "Bord6";
            this.Bord6.UseVisualStyleBackColor = true;
            // 
            // Bord2
            // 
            this.Bord2.Location = new System.Drawing.Point(300, 32);
            this.Bord2.Name = "Bord2";
            this.Bord2.Size = new System.Drawing.Size(153, 103);
            this.Bord2.TabIndex = 1;
            this.Bord2.Text = "Bord2";
            this.Bord2.UseVisualStyleBackColor = true;
            // 
            // Bord4
            // 
            this.Bord4.Location = new System.Drawing.Point(100, 157);
            this.Bord4.Name = "Bord4";
            this.Bord4.Size = new System.Drawing.Size(153, 103);
            this.Bord4.TabIndex = 2;
            this.Bord4.Text = "Bord4";
            this.Bord4.UseVisualStyleBackColor = true;
            // 
            // Bord1
            // 
            this.Bord1.Location = new System.Drawing.Point(100, 32);
            this.Bord1.Name = "Bord1";
            this.Bord1.Size = new System.Drawing.Size(153, 103);
            this.Bord1.TabIndex = 0;
            this.Bord1.Text = "Bord1";
            this.Bord1.UseVisualStyleBackColor = true;
            // 
            // BokaÄndra
            // 
            this.BokaÄndra.Controls.Add(this.Ändra);
            this.BokaÄndra.Controls.Add(this.Boka);
            this.BokaÄndra.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BokaÄndra.Location = new System.Drawing.Point(0, 0);
            this.BokaÄndra.Name = "BokaÄndra";
            this.BokaÄndra.Size = new System.Drawing.Size(800, 450);
            this.BokaÄndra.TabIndex = 10;
            this.BokaÄndra.Visible = false;
            this.BokaÄndra.Paint += new System.Windows.Forms.PaintEventHandler(this.BokaÄndra_Paint);
            // 
            // Ändra
            // 
            this.Ändra.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Ändra.Location = new System.Drawing.Point(287, 237);
            this.Ändra.Name = "Ändra";
            this.Ändra.Size = new System.Drawing.Size(187, 91);
            this.Ändra.TabIndex = 1;
            this.Ändra.Text = "Ändra";
            this.Ändra.UseVisualStyleBackColor = true;
            this.Ändra.Click += new System.EventHandler(this.Ändra_Click);
            // 
            // Boka
            // 
            this.Boka.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Boka.Location = new System.Drawing.Point(287, 111);
            this.Boka.Name = "Boka";
            this.Boka.Size = new System.Drawing.Size(187, 91);
            this.Boka.TabIndex = 0;
            this.Boka.Text = "Boka";
            this.Boka.UseVisualStyleBackColor = true;
            this.Boka.Click += new System.EventHandler(this.Boka_Click);
            // 
            // BordÄndra
            // 
            this.BordÄndra.Controls.Add(this.BordÄndra9);
            this.BordÄndra.Controls.Add(this.BordÄndra8);
            this.BordÄndra.Controls.Add(this.BordÄndra7);
            this.BordÄndra.Controls.Add(this.BordÄndra6);
            this.BordÄndra.Controls.Add(this.BordÄndra5);
            this.BordÄndra.Controls.Add(this.BordÄndra4);
            this.BordÄndra.Controls.Add(this.BordÄndra3);
            this.BordÄndra.Controls.Add(this.BordÄndra2);
            this.BordÄndra.Controls.Add(this.BordÄndra1);
            this.BordÄndra.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BordÄndra.Location = new System.Drawing.Point(0, 0);
            this.BordÄndra.Name = "BordÄndra";
            this.BordÄndra.Size = new System.Drawing.Size(800, 450);
            this.BordÄndra.TabIndex = 10;
            this.BordÄndra.Visible = false;
            // 
            // BordÄndra9
            // 
            this.BordÄndra9.Location = new System.Drawing.Point(500, 293);
            this.BordÄndra9.Name = "BordÄndra9";
            this.BordÄndra9.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra9.TabIndex = 9;
            this.BordÄndra9.Text = "Bord9";
            this.BordÄndra9.UseVisualStyleBackColor = true;
            this.BordÄndra9.Click += new System.EventHandler(this.BordÄndra9_Click);
            // 
            // BordÄndra8
            // 
            this.BordÄndra8.Location = new System.Drawing.Point(300, 293);
            this.BordÄndra8.Name = "BordÄndra8";
            this.BordÄndra8.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra8.TabIndex = 8;
            this.BordÄndra8.Text = "Bord8";
            this.BordÄndra8.UseVisualStyleBackColor = true;
            this.BordÄndra8.Click += new System.EventHandler(this.BordÄndra8_Click);
            // 
            // BordÄndra7
            // 
            this.BordÄndra7.Location = new System.Drawing.Point(100, 293);
            this.BordÄndra7.Name = "BordÄndra7";
            this.BordÄndra7.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra7.TabIndex = 7;
            this.BordÄndra7.Text = "Bord7";
            this.BordÄndra7.UseVisualStyleBackColor = true;
            this.BordÄndra7.Click += new System.EventHandler(this.BordÄndra7_Click);
            // 
            // BordÄndra6
            // 
            this.BordÄndra6.Location = new System.Drawing.Point(500, 157);
            this.BordÄndra6.Name = "BordÄndra6";
            this.BordÄndra6.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra6.TabIndex = 6;
            this.BordÄndra6.Text = "Bord6";
            this.BordÄndra6.UseVisualStyleBackColor = true;
            this.BordÄndra6.Click += new System.EventHandler(this.BordÄndra6_Click);
            // 
            // BordÄndra5
            // 
            this.BordÄndra5.Location = new System.Drawing.Point(300, 157);
            this.BordÄndra5.Name = "BordÄndra5";
            this.BordÄndra5.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra5.TabIndex = 4;
            this.BordÄndra5.Text = "Bord5";
            this.BordÄndra5.UseVisualStyleBackColor = true;
            this.BordÄndra5.Click += new System.EventHandler(this.BordÄndra5_Click);
            // 
            // BordÄndra4
            // 
            this.BordÄndra4.Location = new System.Drawing.Point(100, 157);
            this.BordÄndra4.Name = "BordÄndra4";
            this.BordÄndra4.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra4.TabIndex = 3;
            this.BordÄndra4.Text = "Bord4";
            this.BordÄndra4.UseVisualStyleBackColor = true;
            this.BordÄndra4.Click += new System.EventHandler(this.BordÄndra4_Click);
            // 
            // BordÄndra3
            // 
            this.BordÄndra3.Location = new System.Drawing.Point(500, 32);
            this.BordÄndra3.Name = "BordÄndra3";
            this.BordÄndra3.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra3.TabIndex = 1;
            this.BordÄndra3.Text = "Bord3";
            this.BordÄndra3.UseVisualStyleBackColor = true;
            this.BordÄndra3.Click += new System.EventHandler(this.BordÄndra3_Click);
            // 
            // BordÄndra2
            // 
            this.BordÄndra2.Location = new System.Drawing.Point(300, 32);
            this.BordÄndra2.Name = "BordÄndra2";
            this.BordÄndra2.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra2.TabIndex = 2;
            this.BordÄndra2.Text = "Bord2";
            this.BordÄndra2.UseVisualStyleBackColor = true;
            this.BordÄndra2.Click += new System.EventHandler(this.BordÄndra2_Click);
            // 
            // BordÄndra1
            // 
            this.BordÄndra1.Location = new System.Drawing.Point(100, 32);
            this.BordÄndra1.Name = "BordÄndra1";
            this.BordÄndra1.Size = new System.Drawing.Size(153, 103);
            this.BordÄndra1.TabIndex = 0;
            this.BordÄndra1.Text = "Bord1";
            this.BordÄndra1.UseVisualStyleBackColor = true;
            this.BordÄndra1.Click += new System.EventHandler(this.BordÄndra1_Click);
            // 
            // ÄndraMeny
            // 
            this.ÄndraMeny.Controls.Add(this.button2);
            this.ÄndraMeny.Controls.Add(this.textBox2);
            this.ÄndraMeny.Controls.Add(this.textBox1);
            this.ÄndraMeny.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ÄndraMeny.Location = new System.Drawing.Point(0, 0);
            this.ÄndraMeny.Name = "ÄndraMeny";
            this.ÄndraMeny.Size = new System.Drawing.Size(800, 450);
            this.ÄndraMeny.TabIndex = 10;
            this.ÄndraMeny.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(592, 372);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 75);
            this.button2.TabIndex = 2;
            this.button2.Text = "Spara";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.textBox2.Location = new System.Drawing.Point(111, 245);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(557, 83);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "antal";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F);
            this.textBox1.Location = new System.Drawing.Point(111, 102);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(557, 83);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Namn";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Välj);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.Selected);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.Location = new System.Drawing.Point(328, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "lalalalallala";
            // 
            // Välj
            // 
            this.Välj.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Välj.Location = new System.Drawing.Point(319, 245);
            this.Välj.Name = "Välj";
            this.Välj.Size = new System.Drawing.Size(105, 50);
            this.Välj.TabIndex = 3;
            this.Välj.Text = "Rensa";
            this.Välj.UseVisualStyleBackColor = true;
            this.Välj.Click += new System.EventHandler(this.Välj_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(176, 245);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(105, 50);
            this.button6.TabIndex = 2;
            this.button6.Text = "förra";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(459, 245);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 50);
            this.button5.TabIndex = 1;
            this.button5.Text = "Nästa";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Selected
            // 
            this.Selected.AutoSize = true;
            this.Selected.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Selected.Location = new System.Drawing.Point(353, 172);
            this.Selected.Name = "Selected";
            this.Selected.Size = new System.Drawing.Size(42, 46);
            this.Selected.TabIndex = 0;
            this.Selected.Text = "1";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(703, 32);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Back";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(308, 372);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(166, 54);
            this.button7.TabIndex = 3;
            this.button7.Text = "Stäng";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainMeny);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.ÄndraMeny);
            this.Controls.Add(this.BokaÄndra);
            this.Controls.Add(this.BordÄndra);
            this.Controls.Add(this.BordBoka);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MainMeny.ResumeLayout(false);
            this.MainMeny.PerformLayout();
            this.BordBoka.ResumeLayout(false);
            this.BokaÄndra.ResumeLayout(false);
            this.BordÄndra.ResumeLayout(false);
            this.ÄndraMeny.ResumeLayout(false);
            this.ÄndraMeny.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel MainMeny;
        private System.Windows.Forms.Panel BordBoka;
        private System.Windows.Forms.Button Bord2;
        private System.Windows.Forms.Button Bord1;
        private System.Windows.Forms.Button Bord9;
        private System.Windows.Forms.Button Bord8;
        private System.Windows.Forms.Button Bord5;
        private System.Windows.Forms.Button Bord3;
        private System.Windows.Forms.Button Bord7;
        private System.Windows.Forms.Button Bord6;
        private System.Windows.Forms.Button Bord4;
        private System.Windows.Forms.Panel BokaÄndra;
        private System.Windows.Forms.Button Ändra;
        private System.Windows.Forms.Button Boka;
        private System.Windows.Forms.Panel BordÄndra;
        private System.Windows.Forms.Button BordÄndra9;
        private System.Windows.Forms.Button BordÄndra8;
        private System.Windows.Forms.Button BordÄndra7;
        private System.Windows.Forms.Button BordÄndra6;
        private System.Windows.Forms.Button BordÄndra5;
        private System.Windows.Forms.Button BordÄndra4;
        private System.Windows.Forms.Button BordÄndra3;
        private System.Windows.Forms.Button BordÄndra2;
        private System.Windows.Forms.Button BordÄndra1;
        private System.Windows.Forms.Panel ÄndraMeny;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label Selected;
        private System.Windows.Forms.Button Välj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
    }
}

